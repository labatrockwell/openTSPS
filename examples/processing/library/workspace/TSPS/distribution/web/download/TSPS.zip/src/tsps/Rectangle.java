package tsps;

public class Rectangle
{
	public float x, y, width, height;
};